package com.bookslot;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
public class AppointmentTest {
	
	@Autowired
     private MockMvc mockMvc;

	/*@Test
	public void AppoTest() throws Exception {
    System.out.println("//////-/////////");
    System.out.println(MockMvcRequestBuilders.get("/theaterType"));
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("http://localhost:8200/theaterType")
    .contentType(MediaType.APPLICATION_JSON)
    )
    .andExpect(MockMvcResultMatchers.status().isOk())
    .andReturn();

		}
	*/
	@Test
	public void AppoTests() throws Exception {
    System.out.println("//////-/////////");
    System.out.println(MockMvcRequestBuilders.get("/searchBypatientName"));
    MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("http://localhost:8200/searchBypatientName/test")
    .contentType(MediaType.APPLICATION_JSON)
    )
   //andExpect(jsonPath("$.id", is(this.bookmarkList.get(0).getId().intValue())))
   //.andExpect(MockMvcResultMatchers.status().isOk())
   // .andExpect(MockMvcResultMatchers.jsonPath("$.patientName").value("Test"))
    .andExpect(MockMvcResultMatchers.jsonPath("$[*].patientName").value("Test"))
   // .andExpect(jsonPath("patientName", is("Test")))
    //.andExpect(jsonPath("$", is("Test")))
   // .andExpect(MockMvcResultMatchers.jsonPath("$.length").value(1))
    .andReturn();

		}


}


