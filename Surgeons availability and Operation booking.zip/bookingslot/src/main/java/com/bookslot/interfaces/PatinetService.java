package com.bookslot.interfaces;

import com.bookslot.entitity.Patient;

public interface PatinetService {
	public Patient addPatient(Patient patient);
	public Patient searchBypatientName(String patientName);

}