package com.bookslot.interfaces;

import java.util.List;

import com.bookslot.entitity.Appointment;

public interface TheaterBookingService {
	public Appointment addAppointment(Appointment appointment);
	public List<Appointment> searchByPatientId(String PatientId);
	public Appointment updateAppointment(Appointment appointment);
	public void deleteEmployeeBySlotId(String slotId);
}
