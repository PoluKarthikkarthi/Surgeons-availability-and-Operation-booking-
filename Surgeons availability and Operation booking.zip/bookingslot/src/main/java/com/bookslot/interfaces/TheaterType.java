package com.bookslot.interfaces;

import java.util.List;

import com.bookslot.entitity.Theatre;

public interface TheaterType {
	public Theatre addTheater(Theatre theaters);
	public List<Theatre> searchBytheatreOID(String theatreOID);

}
