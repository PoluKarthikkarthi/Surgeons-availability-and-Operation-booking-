package com.bookslot.interfaces;

import com.bookslot.entitity.Practitioner;

public interface PractitionerService {
	public Practitioner addPactitioner(Practitioner practitoner);
	public Practitioner searchBypratitionerName(String practitionerName);
}
