package com.bookslot.sysconfig;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/*
public class ApptSecurityConfig {
	
	
}
*/


@Configuration
@EnableWebSecurity(debug = true)
public class ApptSecurityConfig {
	
	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	http.authorizeHttpRequests().requestMatchers("/welcome/**").permitAll()
	.requestMatchers("/v2/api-docs",
			"/v3/api-docs/**",
			"/swagger-resources/configuration/ui",  
			"/swagger-resources/configuration/security", 
			"/webjars/**",
			"/swagger-ui.html","/swagger-ui/**").permitAll()
	.requestMatchers("/login/**").permitAll()
	.requestMatchers("/theaterType/**").permitAll()
	.requestMatchers("/searchBypatientName/**").permitAll()
	.requestMatchers("/PostPatient/**").permitAll()
	.requestMatchers("/CreateTheater/**").permitAll()
	.requestMatchers("/GetTheaterByPatientId/**").permitAll()
	.requestMatchers("/CancelTheater/**").permitAll()
	.requestMatchers("/postpractitioner/**").permitAll()
	.requestMatchers("/searchBypractitionerName/**").permitAll()
	.requestMatchers("/deleteTheater/**").permitAll()
	.requestMatchers("/CreateType/**").authenticated()
	.requestMatchers("/GetTheaterBytheatreOID/**").permitAll()
	.requestMatchers("/GetSlots/**").permitAll()
    .requestMatchers("/CreateAppointment").permitAll()
    .requestMatchers("/CancelAppointment").permitAll()
	.requestMatchers("/GetAppointmentsByPatientId/**").permitAll();
	http.httpBasic();
	http.cors().disable();
	http.csrf().disable(); 
	return http.build();
    }
	

}

