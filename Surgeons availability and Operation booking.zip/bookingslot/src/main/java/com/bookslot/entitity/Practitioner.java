package com.bookslot.entitity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "practitioner")
public class Practitioner {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long practitionerId;

	@Column(nullable = false,unique = false)
	private String practitionerName;
	
	@Column(nullable = false,unique = false)
	private String specialityCode;
	
	@Column(nullable = false,unique = false)
	private String consultationFees;
	
	@Column(nullable = false,unique = false)
	private String consultationTimings;

	public Practitioner() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Practitioner(Long practitionerId, String practitionerName, String specialityCode, String yearsofexperience,
			String registrationNumber, String qualification, String languagesknown, String consultationFees,
			String consultationTimings) {
		super();
		this.practitionerId = practitionerId;
		this.practitionerName = practitionerName;
		this.specialityCode = specialityCode;
		this.consultationFees = consultationFees;
		this.consultationTimings = consultationTimings;
	}

	@Override
	public String toString() {
		return "Practitioner [practitionerId=" + practitionerId + ", practitionerName=" + practitionerName
				+ ", specialityCode=" + specialityCode + ", consultationFees=" + consultationFees
				+ ", consultationTimings=" + consultationTimings + "]";
	}

	public Long getPractitionerId() {
		return practitionerId;
	}

	public void setPractitionerId(Long practitionerId) {
		this.practitionerId = practitionerId;
	}

	public String getPractitionerName() {
		return practitionerName;
	}

	public void setPractitionerName(String practitionerName) {
		this.practitionerName = practitionerName;
	}

	public String getSpecialityCode() {
		return specialityCode;
	}

	public void setSpecialityCode(String specialityCode) {
		this.specialityCode = specialityCode;
	}

	public String getConsultationFees() {
		return consultationFees;
	}

	public void setConsultationFees(String consultationFees) {
		this.consultationFees = consultationFees;
	}

	public String getConsultationTimings() {
		return consultationTimings;
	}

	public void setConsultationTimings(String consultationTimings) {
		this.consultationTimings = consultationTimings;
	}


}
