package com.bookslot.entitity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "theaterbookedapp")

public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long appointmentId;
	
	@Column(nullable = false,unique = false)
	private String patientId;
	
	@Column(nullable = false,unique = false)
	private String doctorId;
	
	@Column(nullable = false,unique = false)
	private String slotId;
	
	@Column(nullable = false,unique = false)
	private String status;
	
	@Column(nullable = false,unique = false)
	private String dateofapp;
	
	@Column(nullable = false,unique = false)
	private String startdttm;
	
	@Column(nullable = false,unique = false)
	private String enddttm;
	
	@Column(nullable = false,unique = false)
	private String cheifcomplaint;
	
	@Column(nullable = false,unique = false)
	private String practionerid;
	
	@Column(nullable = false,unique = false)
	private String theatreid;
	
	@Column(nullable = false,unique = false)
	private String theatretype;
	
	
	public String getTheatretype() {
		return theatretype;
	}

	public void setTheatretype(String theatretype) {
		this.theatretype = theatretype;
	}

	public String getDateofapp() {
		return dateofapp;
	}

	public void setDateofapp(String dateofapp) {
		this.dateofapp = dateofapp;
	}

	public String getTimeofapp() {
		return timeofapp;
	}

	public void setTimeofapp(String timeofapp) {
		this.timeofapp = timeofapp;
	}

	@Column(nullable = false,unique = false)
	private String timeofapp;
	
	public Long getappointmentId() {
		return appointmentId;
	}

	public void setappointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}
	
    public String getpatientId() {
		return patientId;
	}

	public void setpatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getdoctorId() {
		return doctorId;
	}


	public void setdoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	
	public String getslotId() {
		return slotId;
	}

	public void setslotId(String slotId) {
		this.slotId = slotId;
	}

	public String getstatus() {
		return status;
	}

	public void setstatus(String status) {
		this.status = status;
	}

	public String getStartdttm() {
		return startdttm;
	}

	public void setStartdttm(String startdttm) {
		this.startdttm = startdttm;
	}

	public String getEnddttm() {
		return enddttm;
	}

	public void setEnddttm(String enddttm) {
		this.enddttm = enddttm;
	}

	public String getCheifcomplaint() {
		return cheifcomplaint;
	}

	public void setCheifcomplaint(String cheifcomplaint) {
		this.cheifcomplaint = cheifcomplaint;
	}
	
	
	public String getPractionerid() {
		return practionerid;
	}

	public void setPractionerid(String practionerid) {
		this.practionerid = practionerid;
	}

	public String getTheatreid() {
		return theatreid;
	}

	public void setTheatreid(String theatreid) {
		this.theatreid = theatreid;
	}

	
	
	
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Appointment(Long appointmentId, String patientId, String doctorId, String slotId, String status,String dateofapp, String timeofapp ,String startdttm,String enddttm,String cheifcomplaint,String practionerid,String theatreid,String theatretype ) {
		super();
		this.appointmentId = appointmentId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.slotId = slotId;
		this.status = status;
		this.dateofapp = dateofapp;
		this.timeofapp = timeofapp;
		this.startdttm = startdttm;
		this.enddttm = enddttm;
		this.cheifcomplaint = cheifcomplaint;
		this.practionerid=practionerid;
		this.theatreid=theatreid;
		this.theatretype=theatretype;
		
	}

	

	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", patientId=" + patientId + ", doctorId="
				+ doctorId + ", slotId=" + slotId + ", status=" + status +", date="+ dateofapp +", time="+timeofapp+", "
						+ "startdttm=" + startdttm +", enddttm=" + enddttm +",cheifcomplaint=" + cheifcomplaint+" ,"
								+ "practionerid=" + practionerid+" ,theatreid=" + theatreid+",theatretype=" + theatretype+"]";
	}
	
	
}
