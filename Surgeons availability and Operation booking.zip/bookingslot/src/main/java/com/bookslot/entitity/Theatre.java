package com.bookslot.entitity;
import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "theatre")
public class Theatre {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long theatreID;
    
    @Column(nullable = false, unique = true)
    private String theatreOID;
    
    @Column(nullable = false)
    private String theatreName;
    
    @Column(nullable = false)
    private String status ;

	public Long getTheatreID() {
		return theatreID;
	}

	public void setTheatreID(Long theatreID) {
		this.theatreID = theatreID;
	}

	public String getTheatreOID() {
		return theatreOID;
	}

	public void setTheatreOID(String theatreOID) {
		this.theatreOID = theatreOID;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	 public Theatre() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Theatre(Long theatreID,String theatreOID , String theatreName, String status) {
		super();
		this.theatreID = theatreID;
		this.theatreOID = theatreOID;
		this.theatreName = theatreName;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Theatre [theatreID=" + theatreID + ", theatreOID=" + theatreOID + ", theatreName="
				+ theatreName + ", status=" + status +  "]";
	}

}
