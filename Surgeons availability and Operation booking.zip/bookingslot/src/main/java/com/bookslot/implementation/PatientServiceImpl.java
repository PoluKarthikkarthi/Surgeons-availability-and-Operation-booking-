package com.bookslot.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookslot.entitity.Patient;
import com.bookslot.interfaces.PatinetService;
import com.bookslot.repo.PatientRepo;



@Service
public class PatientServiceImpl implements PatinetService{
	
	@Autowired
	PatientRepo patientrepository;

	@Override
	public Patient addPatient(Patient patient) {
		return patientrepository.save(patient);
	}
	
	@Override
	public Patient searchBypatientName(String patientName) {
		return patientrepository.findBypatientName(patientName);
	}

}



