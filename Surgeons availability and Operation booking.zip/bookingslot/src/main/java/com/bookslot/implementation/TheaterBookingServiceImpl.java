package com.bookslot.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookslot.entitity.Appointment;
import com.bookslot.interfaces.TheaterBookingService;
import com.bookslot.repo.TheaterRepo;

@Service
public class TheaterBookingServiceImpl implements TheaterBookingService {

	@Autowired
	TheaterRepo appointmentrepository;
	
	//@Autowired
	//SlotRepository slotrepository;
	@Override
	public Appointment addAppointment(Appointment appointment) {
		return appointmentrepository.save(appointment);
	}
	
	@Override
	public List<Appointment> searchByPatientId(String PatientId) {
		return (List<Appointment>) appointmentrepository.findByPatientId(PatientId);
	}
	
	@Override
	public Appointment updateAppointment(Appointment appointment) {
		Appointment appt = appointmentrepository.findById(appointment.getappointmentId()).orElse(null);
		appt.setstatus(appointment.getstatus());
		return appointmentrepository.save(appt);
	}

	@Override
	public void deleteEmployeeBySlotId(String slotId) {
		// TODO Auto-generated method stub
		 appointmentrepository.deleteBySlotId(slotId);
	}
	
	
}
