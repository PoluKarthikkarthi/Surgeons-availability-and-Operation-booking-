package com.bookslot.implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookslot.entitity.Patient;
import com.bookslot.entitity.Practitioner;
import com.bookslot.interfaces.PractitionerService;
import com.bookslot.repo.PractitionerRepo;

@Service
public class PractitionerServiceImpl implements PractitionerService {
	@Autowired
	PractitionerRepo practitionerRepo;

	@Override
	public Practitioner addPactitioner(Practitioner practitoner) {
		return practitionerRepo.save(practitoner);
	}
	
	@Override
	public Practitioner searchBypratitionerName(String practitionerName) {
		return practitionerRepo.findBypractitionerName(practitionerName);
	}
}
