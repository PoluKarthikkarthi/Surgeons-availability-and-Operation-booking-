package com.bookslot.implementation;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookslot.entitity.Appointment;
import com.bookslot.entitity.Theatre;
import com.bookslot.interfaces.TheaterBookingService;
import com.bookslot.interfaces.TheaterType;
import com.bookslot.repo.TheaterRepo;
import com.bookslot.repo.TypeRepo;

@Service
public class TheaterTypeServicesImpl implements TheaterType {

	@Autowired
	TypeRepo typerepository;

	@Override
	public Theatre addTheater(Theatre theaters) {
		// TODO Auto-generated method stub
		return typerepository.save(theaters);
	}

	@Override
	public List<Theatre> searchBytheatreOID(String theatreOID) {
		// TODO Auto-generated method stub
		return (List<Theatre>) typerepository.findBytheatreOID(theatreOID);
	}
	
	//@Autowired
	//SlotRepository slotrepository;
	
}

