package com.bookslot.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.bookslot.entitity.Appointment;

import jakarta.transaction.Transactional;
//@Transactiona
public interface TheaterRepo extends CrudRepository<Appointment, Long>{
	public List <Appointment> findByPatientId(String PatientId);
	@Transactional
	public void deleteBySlotId(String SlotId);

}
