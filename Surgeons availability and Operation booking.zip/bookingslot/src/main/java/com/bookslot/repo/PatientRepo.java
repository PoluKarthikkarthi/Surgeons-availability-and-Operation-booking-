package com.bookslot.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bookslot.entitity.Patient;




@Repository
public interface PatientRepo extends CrudRepository<Patient, String>{
	public Patient findBypatientName(String patientName);
}
//public Patient findBymobileno(String mobileno);

