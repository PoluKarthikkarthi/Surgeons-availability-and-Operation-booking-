package com.bookslot.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.bookslot.entitity.Theatre;

public interface TypeRepo extends CrudRepository<Theatre, String>{
	public List <Theatre> findBytheatreOID(String theatreOID);

}
