package com.bookslot.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bookslot.entitity.Practitioner;
@Repository
public interface PractitionerRepo  extends CrudRepository<Practitioner, String>{
	public Practitioner findBypractitionerName(String practitionerName);
}


