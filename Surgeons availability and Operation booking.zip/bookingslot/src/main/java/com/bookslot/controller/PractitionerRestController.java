package com.bookslot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.bookslot.entitity.Practitioner;
import com.bookslot.interfaces.PractitionerService;

@RestController
public class PractitionerRestController {
	@Autowired
	PractitionerService practitionerService;
	
	@PostMapping("/postpractitioner")	
	public Practitioner addPactitioner(@RequestBody Practitioner practitioner) {
		return practitionerService.addPactitioner(practitioner);
	}
	
	@GetMapping("/searchBypractitionerName/{practitionerName}")
	public Practitioner searchBypratitionerName(@PathVariable String practitionerName) {
		return practitionerService.searchBypratitionerName(practitionerName);
	}
}
