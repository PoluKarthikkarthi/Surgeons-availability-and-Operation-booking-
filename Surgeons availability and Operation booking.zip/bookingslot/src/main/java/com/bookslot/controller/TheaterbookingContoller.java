package com.bookslot.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookslot.entitity.Appointment;
import com.bookslot.interfaces.TheaterBookingService;

@RestController
public class TheaterbookingContoller {

	@Autowired
	TheaterBookingService apposervice;
	
	
	@PostMapping("/CreateTheater")	
	public Appointment addAppointment(@RequestBody Appointment appointment) throws Exception {
		return apposervice.addAppointment(appointment);
	}
	
	@GetMapping("/GetTheaterByPatientId/{PatientId}")
	public List<Appointment> searchPatientId(@PathVariable String PatientId) {
		return apposervice.searchByPatientId(PatientId);
	}
	
	@PutMapping("/CancelTheater")
	public Appointment updateAppointment(@RequestBody Appointment appointment) {
		return apposervice.updateAppointment(appointment);
	}
	
	
	@DeleteMapping("/deleteTheater/{SlotId}")
	public void deleteEmployee(@PathVariable("SlotId") String SlotId) {
		 apposervice.deleteEmployeeBySlotId(SlotId);
	}
	
	@DeleteMapping("/deleteTheatermutiple/{SlotId}")
	public void deleteEmployeeSlot(@PathVariable("SlotId") String SlotId) {
		//this.chainOfCallbackMethods(SlotId);
		 //apposervice.deleteEmployeeBySlotId(SlotId);
		/*
		  CompletableFuture.
          supplyAsync(() -> //CALL MORTAGE INFO REST, executor).
          thenAccept(x -> {
             // accountDetails.setMortgageAccountId(x.getReqdField())
          }));
          CompletableFuture.
          supplyAsync(() -> //CALL MORTAGE INFO REST, executor).
          thenAccep(x -> {
             // accountDetails.setMortgageAccountId(x.getReqdField())
          }));
          */
		
	}
	
	private static void chainOfCallbackMethods(String SlotId) {
		CompletableFuture<Void> future = CompletableFuture.supplyAsync(() -> {
			//apposervice.deleteEmployeeBySlotId(SlotId);
			return "delete in employee";
		}).thenApply(value -> {
			//apposervice.deleteEmployeeBySlotId(SlotId);
			return "delete in patinet table";
		}).thenAccept(System.out::println);

	}

}
