package com.bookslot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookslot.entitity.Appointment;
import com.bookslot.entitity.Theatre;
import com.bookslot.interfaces.TheaterBookingService;
import com.bookslot.interfaces.TheaterType;

@RestController
public class TheaterTypeController {

	@Autowired
	TheaterType apposervice;
	
	
	@PostMapping("/CreateType")	
	public Theatre addAppointment(@RequestBody Theatre thea) throws Exception {
		return apposervice.addTheater(thea);
	}
	
	@GetMapping("/GetTheaterBytheatreOID/{theatreOID}")
	public List<Theatre> searchPatientId(@PathVariable String theatreOID) {
		return apposervice.searchBytheatreOID(theatreOID);
	}

}
