package com.bookslot.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.bookslot.entitity.Patient;
import com.bookslot.interfaces.PatinetService;
import com.bookslot.repo.PatientRepo;



@RestController
public class PatinetController {
	
	@Autowired
	PatinetService patientservice;
	
	@Autowired
	PatientRepo patientrepository;
	
	@PostMapping("/PostPatient")	
	public Patient addPatient(@RequestBody Patient patient) {
		return patientservice.addPatient(patient);
	}
	
	@GetMapping("/check")
	public String saple() {
		return "Server up";
	}
	
	@GetMapping("/theaterType")
	public ArrayList<String> typetheater() {
		ArrayList<String> data = new ArrayList<>();
		data.add("modular OT");
		data.add("orthopedic OT");
		data.add("GeneralSuregery OT");
		data.add("HeadNeck OT");
		data.add("Endoscopy OT");
		data.add("Emergency OT");
		data.add("Maternity OT");
		return data;
		
	}
	
	@GetMapping("/searchBypatientName/{patientName}")
	public Patient searchBypatientName(@PathVariable String patientName) {
		System.out.print("samples:"+patientservice.searchBypatientName(patientName));
		/*if(patientservice.searchBypatientName(patientName)==null) {
			throw new ResponseStatusException(500, "HTTP Status will be NOT FOUND (CODE 404)\n", null);   
		}else {
			return patientservice.searchBypatientName(patientName);
		}
		*/
		return patientservice.searchBypatientName(patientName);
	
		
	
	}

}